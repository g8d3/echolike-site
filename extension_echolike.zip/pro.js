// EchoLike Pro gate (q54 scaffold, q63 license check). Stored license state,
// OFF by default. Features gate on isPro(storageState).
// Activation checks the key against the license server (POST /licenses/validate);
// only an ok+valid+active answer flips the stored state to active+verified.
(function (root, factory) {
  const api = factory();
  if (typeof module !== "undefined" && module.exports) module.exports = api;
  else root.ProGate = api;
})(typeof self !== "undefined" ? self : this, function () {
  // Same origin the site and update_url use; the extension only sends the key.
  const LICENSE_ENDPOINT = "https://echolike.app/licenses/validate";
  const TIMEOUT_MS = 8000;
  function estadoPro(s) {
    const p = (s && s.pro) || {};
    return {
      clave: typeof p.clave === "string" ? p.clave : "",
      activo: p.activo === true,
      verificado: p.verificado === true,
    };
  }
  // Free unless a verified key is stored AND active.
  function isPro(s) {
    const p = estadoPro(s);
    return !!(p.activo && p.verificado && p.clave);
  }
  function normalizarClave(c) {
    return String(c == null ? "" : c).trim().toUpperCase().replace(/[\s-]+/g, "");
  }
  // Ask the license server whether this key is an active paid license.
  // Returns {ok:true, pro:true|false, ...} for a reached server, or
  // {ok:false, error} on empty key / network / non-2xx. Fails closed:
  // anything other than an explicit valid+active leaves Pro off.
  async function validarLicenciaServidor(clave, opts) {
    const key = normalizarClave(clave);
    if (!key) return { ok: false, pro: false, error: "EMPTY_KEY" };
    const o = opts || {};
    const endpoint = o.endpoint || LICENSE_ENDPOINT;
    const f = o.fetch || (typeof fetch === "function" ? fetch : null);
    if (!f) return { ok: false, pro: false, error: "NO_FETCH" };
    const ctrl = typeof AbortController === "function" ? new AbortController() : null;
    const timer = ctrl ? setTimeout(() => ctrl.abort(), o.timeoutMs || TIMEOUT_MS) : null;
    try {
      const r = await f(endpoint, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ key }),
        signal: ctrl ? ctrl.signal : undefined,
      });
      if (!r || !r.ok) return { ok: false, pro: false, error: "HTTP_" + (r ? r.status : "0") };
      const j = await r.json();
      const valid = !!(j && j.valid === true);
      const active = !!(j && j.active === true);
      return { ok: true, pro: valid && active, valid, active, status: (j && j.status) || "" };
    } catch (e) {
      return { ok: false, pro: false, error: "NETWORK" };
    } finally {
      if (timer) clearTimeout(timer);
    }
  }
  return { LICENSE_ENDPOINT, estadoPro, isPro, normalizarClave, validarLicenciaServidor };
});
