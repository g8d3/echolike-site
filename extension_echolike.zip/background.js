// EchoLike background. Local-first: everything stays in this browser's storage
// unless the user turns sync on (opt-in). With sync: persistent queue, direct
// POST to the user's own inbox, confirmations inline in the same response.
const ext = typeof browser !== "undefined" ? browser : chrome;
const t = (k, s) => { try { const m = ext && ext.i18n && ext.i18n.getMessage(k, s); if (m) return m; } catch (e) {} return k; };
const MAXEV = 20;

async function syncOn() { await migrar(); return !!(await ext.storage.local.get({ sync: false })).sync; }
const INBOX_DEFAULT = "";
// No inbox configured means local-only: likes stay in this browser until the
// reader connects one. Read from this file by operador/pagina_extension.py
// (TRANSPORTE_SIN_INBOX) to judge whether the download page's steps are followable.
const TRANSPORTE_SIN_INBOX = "none";
async function cfgDirect() {
  const s = await ext.storage.local.get({ inbox_url: INBOX_DEFAULT, device_token: "" });
  const url = (s.inbox_url || "").replace(/\/$/, "");
  try { const u = new URL(url); if (u.port === "8904") return { error: t("errIsVault") }; } catch (e) {}
  if (!/^https?:\/\/[^/]+$/.test(url) && !/^https?:\/\/[^/]+\/[^\s]*$/.test(url)) return { error: t("errBadInboxUrl") };
  if (!s.device_token) return { error: t("errNoToken") };
  return { inbox_url: url, device_token: s.device_token };
}
// Phone clocks are not in sync with the PC (measured: ~300 ms), and that error lands in every
// latency the server computes. /api/health returns its own now_ms, so the offset is measured
// here (three samples, keep the one with the shortest round trip) instead of guessed.
async function medirDesfase(c) {
  let best = null;
  for (let i = 0; i < 3; i += 1) {
    const t0 = Date.now();
    try {
      const r = await fetch(`${c.inbox_url}/api/health`, { cache: "no-store" });
      const j = await r.json();
      const t1 = Date.now();
      if (typeof j.now_ms === "number") {
        const rtt = t1 - t0;
        const off = Math.round(j.now_ms + rtt / 2 - t1);
        if (best === null || rtt < best.rtt) best = { off, rtt };
      }
    } catch (e) { /* keep whatever sample we have */ }
  }
  if (best !== null) await ext.storage.local.set({ clock_offset_ms: best.off, clock_offset_rtt: best.rtt, clock_offset_at: new Date().toISOString() });
  return best === null ? null : best.off;
}

async function pingDirecto(c) {
  const r = await fetch(`${c.inbox_url}/api/health`, { headers: { authorization: `Bearer ${c.device_token}` } });
  if (!r.ok) throw new Error("inbox HTTP " + r.status);
  medirDesfase(c).catch(() => {});
  return { ok: true };
}
async function publicarDirecto(items, c) { // batch POST; confirmation arrives in the same response
  // Latency the server cannot see: from the click to the moment the like leaves this device.
  // clicked_at and Date.now() are the same clock, so the number is honest even if the clock is off.
  const t0 = Date.now();
  const { clock_offset_ms } = await ext.storage.local.get({ clock_offset_ms: null });
  const conLat = items.map((it) => {
    const c0 = Date.parse(it.clicked_at);
    return Object.assign({}, it, {
      sent_ms: isNaN(c0) ? null : Math.max(0, t0 - c0),
      clock_offset_ms: typeof clock_offset_ms === "number" ? clock_offset_ms : null,
      queued: items.length,
    });
  });
  const r = await fetch(`${c.inbox_url}/api/likes`, {
    method: "POST", headers: { authorization: `Bearer ${c.device_token}`, "content-type": "application/json" },
    body: JSON.stringify({ items: conLat, post_ms: Date.now() - t0 }),
  });
  if (r.status === 401) throw new Error(t("errBadToken"));
  if (r.status === 429) throw new Error("inbox HTTP 429");
  if (!r.ok) throw new Error("inbox HTTP " + r.status + " " + (await r.text()).slice(0, 120));
  const out = await r.json();
  return new Set((out.received || []).map((x) => x.id + "|" + x.kind));
}
async function badge() { // red counter on the icon while events are still failing
  const { cola } = await ext.storage.local.get({ cola: [] });
  const n = cola.length;
  try { ext.action.setBadgeText({ text: n ? String(n) : "" }); if (n) ext.action.setBadgeBackgroundColor({ color: "#d0021b" }); } catch (e) {}
}
async function anotar(item, estado, error) {
  const st = await ext.storage.local.get({ eventos: [] });
  let ev = st.eventos.find((e) => e.uid === item.uid);
  if (!ev) { ev = { uid: item.uid, kind: item.kind, id: item.id || null, handle: item.handle || null, at: item.clicked_at }; st.eventos.unshift(ev); }
  if (!(ev.estado === "recibido" && estado !== "recibido")) ev.estado = estado;
  ev.error = error || null; ev.t = new Date().toISOString();
  await ext.storage.local.set({ eventos: st.eventos.slice(0, MAXEV), ultimo: ev });
  if ((estado === "en cola" || estado === "guardado") && (item.kind === "like" || item.kind === "bookmark")) { // contador «hoy» (fecha local)
    const s = await ext.storage.local.get({ hoy: null }); const d = new Date().toLocaleDateString("en-CA");
    const h = s.hoy && s.hoy.d === d ? s.hoy : { d, likes: 0, bookmarks: 0 };
    h[item.kind === "like" ? "likes" : "bookmarks"]++;
    await ext.storage.local.set({ hoy: h });
  }
  badge();
}
// Queue in storage: survives Chrome sleeping the service worker.
async function encolar(item) { const s = await ext.storage.local.get({ cola: [] }); s.cola.push(item); await ext.storage.local.set({ cola: s.cola }); }
// ---- Enrichment links (v2.10): resolve t.co without any API, using plain HTTP.
// A 301 from t.co is public (no login needed). Article/thread targets become pending
// entries: when the reader later opens that page, content.js scrapes the rendered
// text (their own logged-in session) and sends it back as kind "article"/"followup".
const RESOLVER_MS = 6000;
async function resolverEnlace(href) {
  try {
    const r = await Promise.race([fetch(href, { redirect: "manual" }), new Promise((_, no) => setTimeout(() => no(new Error("t")), RESOLVER_MS))]);
    const loc = r.headers && r.headers.get && r.headers.get("location");
    if (loc) return String(loc).slice(0, 500);
  } catch (e) {}
  return null;
}
async function resolverEnlaces(item) {
  try {
    const links = item && item.links;
    if (!item || !Array.isArray(links) || !links.length) return item;
    for (const l of links) {
      if (!l || l.resuelto || typeof l.href !== "string" || l.href.indexOf("https://t.co/") !== 0) continue;
      const url = await resolverEnlace(l.href);
      if (url) l.resuelto = url;
    }
    const arts = links.map((l) => l.resuelto || "").filter((u) => /\/i\/article\/(\d+)/.test(u));
    if (arts.length && (item.kind === "like" || item.kind === "bookmark") && item.id) {
      const s = await ext.storage.local.get({ pending_links: {} });
      const p = s.pending_links || {};
      for (const u of arts) { const m = u.match(/\/i\/article\/(\d+)/); if (m) p[m[1]] = { tweet: String(item.id), handle: item.handle || null, url: u, at: new Date().toISOString() }; }
      const ks = Object.keys(p).slice(-50);   // bounded: the map is a hint, not an archive
      const rec = {}; for (const k of ks) rec[k] = p[k];
      await ext.storage.local.set({ pending_links: rec });
    }
  } catch (e) {}
  return item;
}
let vaciando = null;
async function vaciarDirecto(cola) { // one batch POST, received in the same response
  const c = await cfgDirect();
  if (c.error) { for (const it of cola) await anotar(it, "error", c.error); return { ok: false, error: c.error }; }
  try {
    const ok = await publicarDirecto(cola, c);
    for (const it of [...cola]) {
      if (ok.has(it.id + "|" + it.kind)) { await anotar(it, "recibido"); cola.shift(); }
      else { await anotar(it, "error", "inbox skipped item"); it.intentos = (it.intentos || 0) + 1; if (it.intentos >= 30) cola.shift(); break; }
    }
    return { ok: true };
  } catch (e) {
    const msg = String(e.message || e);
    for (const it of cola) { it.intentos = (it.intentos || 0) + 1; await anotar(it, "error", msg); }
    while (cola.length && (cola[0].intentos || 0) >= 30) cola.shift();
    return { ok: false, error: msg, fallback: /inbox HTTP (429|5\d\d)/.test(msg) || /Failed to fetch|NetworkError/.test(msg) };
  }
}
async function vaciar() {
  if (vaciando) return vaciando;
  vaciando = (async () => {
    const { cola } = await ext.storage.local.get({ cola: [] });
    if (!cola.length) return { ok: true };
    const r = await vaciarDirecto(cola);
    await ext.storage.local.set({ cola }); return r;
  })();
  try { return await vaciando; } finally { vaciando = null; }
}
// ---- Almacén local (fuente de verdad): lista de items en storage.local["datos"] ----
let guardando = Promise.resolve();
function guardarLocal(item) {
  guardando = guardando.then(async () => {
    const { datos } = await ext.storage.local.get({ datos: [] });
    if (!datos.some((d) => d.uid === item.uid)) { datos.push(Object.assign({ saved_at: new Date().toISOString() }, item)); await ext.storage.local.set({ datos }); }
  }).catch(() => {});
  return guardando;
}
const FORMATO = "echolike-export";
async function exportar() {
  const { datos } = await ext.storage.local.get({ datos: [] });
  return { ok: true, data: { format: FORMATO, format_version: 1, extension_version: ext.runtime.getManifest().version, exported_at: new Date().toISOString(), count: datos.length, items: datos } };
}
async function importar(obj) {
  if (!obj || obj.format !== FORMATO || !Array.isArray(obj.items)) return { ok: false, error: t("errImportFormat") };
  let n = 0;
  await (guardando = guardando.then(async () => {
    const { datos } = await ext.storage.local.get({ datos: [] }); const vistos = new Set(datos.map((d) => d.uid));
    for (const it of obj.items) if (it && typeof it === "object" && it.uid && typeof it.kind === "string" && !vistos.has(it.uid)) { datos.push(it); vistos.add(it.uid); n++; }
    await ext.storage.local.set({ datos });
  }));
  return { ok: true, added: n, total: obj.items.length };
}
async function enviar(item) {
  item.uid = item.uid || crypto.randomUUID();
  if (item.kind !== "ping") await guardarLocal(item);
  if (!(await syncOn())) { if (item.kind === "ping") return { ok: false, uid: item.uid, error: t("errSyncOff") }; await anotar(item, "guardado"); return { ok: true, uid: item.uid, local: true }; }
  if (item.kind === "ping") { // ping = inbox health check, never queued
    try { const c = await cfgDirect(); if (c.error) return { ok: false, uid: item.uid, error: c.error }; await pingDirecto(c); await anotar(item, "recibido"); return { ok: true, uid: item.uid, direct: true }; }
    catch (e) { const msg = String(e.message || e); await anotar(item, "error", msg); return { ok: false, uid: item.uid, error: msg }; }
  }
  await anotar(item, "en cola");
  if (item.kind === "like" || item.kind === "bookmark") {
    await resolverEnlaces(item);
    if (item.truncated && item.id) {   // detail-page re-capture list: bounded, ids only
      const s = await ext.storage.local.get({ truncated_recent: [] });
      const l = (s.truncated_recent || []).filter((x) => x && String(x.id) !== String(item.id));
      l.push({ id: String(item.id), chars: (item.text || "").length, at: new Date().toISOString() });
      await ext.storage.local.set({ truncated_recent: l.slice(-50) });
    }
  }
  await encolar(item);
  const r = await vaciar(); return Object.assign({ uid: item.uid }, r);
}
// ---- Diagnostics (v2.11): the popup hands a URL, the worker runs the same
// capture path the like flow uses and reports every step. The trace ships as a
// kind:diagnostico item through the normal pipeline, so extension, inbox and
// backend all keep the same record; the backend drops a review file for the agent.
const DIAG_MS = 8000;
const espera = (ms) => new Promise((_, no) => setTimeout(() => no(new Error("timeout")), ms));
async function diagnosticar(url) {
  const trace = { at: new Date().toISOString(), version: ext.runtime.getManifest().version, url: String(url || "").slice(0, 500) };
  try {
    const u = trace.url;
    trace.es_tco = /https?:\/\/t\.co\//.test(u);
    let fin = u;
    if (trace.es_tco) {
      try {
        const r = await Promise.race([fetch(u, { redirect: "manual" }), espera(DIAG_MS)]);
        fin = (r.headers && r.headers.get && r.headers.get("location")) || u;
        trace.resuelto = String(fin).slice(0, 500);
      } catch (e) { trace.error_resolver = String((e && e.message) || e).slice(0, 120); }
    }
    let m = String(fin).match(/\/i\/article\/(\d+)/);
    trace.es_articulo = (m && m[1]) || null;
    if (!trace.es_articulo) { m = String(fin).match(/\/status\/(\d+)/); trace.es_tweet = (m && m[1]) || null; }
    trace.sync = await syncOn();
    trace.transport = "direct";
    trace.pagina = null;
    trace.needs_tweet_tab = false;
    try {
      const tabs = await ext.tabs.query({ active: true, currentWindow: true });
      const tab = tabs && tabs[0];
      trace.tab = tab && tab.url ? String(tab.url).slice(0, 200) : null;
      if (tab && tab.id != null && /^https:\/\/(x\.com|twitter\.com|mobile\.(x|twitter)\.com)\//.test(trace.tab || "")) {
        trace.pagina = await Promise.race([ext.tabs.sendMessage(tab.id, { tipo: "diagnosticar" }), espera(DIAG_MS)]);
      } else {
        trace.needs_tweet_tab = true;
      }
    } catch (e) { trace.pagina = { error: String((e && e.message) || e).slice(0, 160) }; }
  } catch (e) { trace.error = String((e && e.message) || e).slice(0, 160); }
  const item = { v: 2, kind: "diagnostico", clicked_at: trace.at, url: trace.url,
    id: "diag-" + Date.now().toString(36), traza: trace, text: JSON.stringify(trace).slice(0, 5000) };
  const r = await enviar(item);
  return Object.assign({ uid: item.uid, trace }, r);
}
async function acuses() {
  // Confirmations arrive inline in every batch POST, so there is nothing to poll.
  return { ok: true, uids: [], nuevos: 0, direct: true };
}
ext.runtime.onMessage.addListener((m, _s, responder) => {
  const p = m && m.tipo === "item" ? enviar(m.item)
    : m && m.tipo === "diagnostico" ? diagnosticar(m.url)
    : m && m.tipo === "selftest" ? autoPrueba("manual")
    : m && m.tipo === "auditar" ? auditar(m.accion, m.detalle, "user").then(() => ({ ok: true }))
    : m && m.tipo === "prueba" ? enviar({ v: 2, kind: "ping", prueba: true, clicked_at: new Date().toISOString() })
    : m && m.tipo === "acuses" ? acuses()
    : m && m.tipo === "exportar" ? exportar()
    : m && m.tipo === "importar" ? importar(m.data)
    : m && m.tipo === "sync" ? (async () => { await ext.storage.local.set({ sync: !!m.on }); return { ok: true, sync: !!m.on }; })()
    : m && m.tipo === "directConfig" ? (async () => { const cur = await ext.storage.local.get({ inbox_url: "", device_token: "" }); const patch = {}; if (m.inbox_url) patch.inbox_url = String(m.inbox_url); if (m.device_token) patch.device_token = String(m.device_token); await ext.storage.local.set(patch); return { ok: true }; })() : null;
  if (!p) return;
  p.then(responder, (e) => responder({ ok: false, error: String(e && e.message || e) })); return true;
});
// First run: sync stays exactly as the user left it (default off); transport is always direct.
let migrada = null;
function migrar() {
  return migrada = migrada || (async () => {
    const st = await ext.storage.local.get(["sync", "transport"]);
    const patch = {};
    if (st.sync === undefined) patch.sync = false;
    if (st.transport !== "direct") patch.transport = "direct";
    if (Object.keys(patch).length) await ext.storage.local.set(patch);
  })();
}
migrar();
function alarmas() { ext.alarms.create("latido", { periodInMinutes: 30 }); ext.alarms.create("reintento", { periodInMinutes: 1 }); }
alarmas();
// ---- Permissions + audit (v2.12): drive mode and per-domain write access.
// Self-test = read-only test runs the agent requests. Drive = the agent may act,
// only on allowed domains. Both default off. Every agent-originated decision
// lands in the audit log on the Agent tab.
async function auditar(accion, detalle, origen) {
  try {
    const s = await ext.storage.local.get({ auditoria: [] });
    const a = s.auditoria || [];
    a.push({ at: new Date().toISOString(), accion: String(accion || ""), detalle: String(detalle || "").slice(0, 300), origen: String(origen || "agent") });
    await ext.storage.local.set({ auditoria: a.slice(-100) });
  } catch (e) {}
}
async function puedeLeer() { const s = await ext.storage.local.get({ selftest: false, drive: false }); return !!(s.selftest || s.drive); }
async function puedeActuar(dominio) {
  const s = await ext.storage.local.get({ drive: false, write: {} });
  if (!s.drive) return false;
  const d = String(dominio || "").toLowerCase();
  return Object.keys(s.write || {}).some((k) => d === k || d.endsWith("." + k));
}
// ---- Agent-triggered self-tests (v2.12): the agent drops an encrypted command
// on the pairing topic; when self-test mode is on, the worker polls it every
// minute, runs the requested action from this browser, and reports back
// through the normal pipeline (kind diagnostico/selftest). Nothing executes
// with selftest off. Latest wins: only unseen command ids run, once each.
async function ejecutarComando(cmd, vistos) {
  if (!cmd || !cmd.id || (vistos && vistos.has(cmd.id))) return 0;
  if (vistos) vistos.add(cmd.id);
  try {
    if (cmd.action === "diagnostico" && cmd.url) await diagnosticar(cmd.url);
    else if (cmd.action === "fetch_page" && cmd.url) await fetchPage(cmd.url);
    else if (cmd.action === "selftest") await autoPrueba("remote:" + cmd.id);
    else return 0;
    await auditar("cmd", cmd.action + " " + (cmd.url || cmd.id || ""), "agent");
    return 1;
  } catch (e) { return 0; }
}
// Direct-transport commands: the inbox doubles as the mailbox (same machine,
// no ntfy needed). One claim per command, first device wins.
async function revisarComandosDirectos() {
  const c = await cfgDirect();
  if (c.error) return { ok: false };
  let j;
  try {
    const r = await Promise.race([fetch(`${c.inbox_url}/api/cmd`, { headers: { authorization: `Bearer ${c.device_token}` } }), espera(DIAG_MS)]);
    if (!r.ok) return { ok: false };
    j = await r.json();
  } catch (e) { return { ok: false }; }
  if (!j || !j.cmd) return { ok: true, hechos: 0 };
  const s = await ext.storage.local.get({ cmd_vistos: [] });
  const vistos = new Set(s.cmd_vistos || []);
  const hechos = await ejecutarComando(j.cmd, vistos);
  await ext.storage.local.set({ cmd_vistos: [...vistos].slice(-50) });
  return { ok: true, hechos };
}
// Agent-driven page fetch (v2.13): open a URL in a background tab, scrape what
// the logged-in session renders, report, close. Drive mode + domain allowlist
// required; every step audited. This is how the agent reads pages the user
// never opens — the session that X login-walls everywhere else.
async function fetchPage(url) {
  const u = String(url || "").slice(0, 500);
  let host = "";
  try { host = new URL(u).hostname.toLowerCase(); } catch (e) { return { ok: false, error: "bad url" }; }
  if (!(await puedeActuar(host))) { await auditar("rechazado", "fetch_page " + host, "worker"); return { ok: false, error: "drive mode or domain not allowed" }; }
  await auditar("fetch_page", u, "agent");
  let tab = null;
  try {
    tab = await ext.tabs.create({ url: u, active: false });
    await Promise.race([
      new Promise((ok, no) => {
        const f = (id, info) => { if (id === tab.id && info.status === "complete") { try { ext.tabs.onUpdated.removeListener(f); } catch (e) {} ok(); } };
        try { ext.tabs.onUpdated.addListener(f); } catch (e) { ok(); }
        setTimeout(() => no(new Error("load timeout")), 25000);
      }), espera(25000)]);
    await new Promise((r) => setTimeout(r, 2500));   // React paints late
    const st = await Promise.race([ext.tabs.sendMessage(tab.id, { tipo: "diagnosticar" }), espera(DIAG_MS)]);
    const out = { ok: true, url: u, state: st || null };
    try {
      const acts = [];
      for (const p of (st && st.posts) || []) {
        if (p.text && p.text.length > 50) acts.push(enviar({ v: 2, kind: "followup", clicked_at: new Date().toISOString(),
          id: p.id, handle: p.handle, url: p.url, text: p.text, truncated: p.truncated, links: p.links || [] }));
      }
      if (st && st.aid && (st.article_chars || 0) > 200) acts.push(enviar({ v: 2, kind: "article", clicked_at: new Date().toISOString(),
        id: "article:" + st.aid, url: u, article_id: st.aid, title: st.article_title || "",
        body: st.article_body || "", truncated: (st.article_chars || 0) >= 100000 }));
      await Promise.all(acts);
      out.sent = acts.length;
    } catch (e) { out.send_error = String((e && e.message) || e).slice(0, 120); }
    await auditar("fetch_page_done", u + " chars=" + ((st && st.article_chars) || 0), "agent");
    return out;
  } catch (e) {
    await auditar("fetch_page_error", u + " " + String((e && e.message) || e).slice(0, 120), "agent");
    return { ok: false, error: String((e && e.message) || e).slice(0, 160) };
  } finally {
    try { if (tab) await ext.tabs.remove(tab.id); } catch (e) {}
  }
}
// Post-update self-test: what runs headless (inbox ping, link resolution,
// queue state). Page visits stay passive: enrichPage picks them up on arrival.
async function autoPrueba(motivo) {
  const trace = { at: new Date().toISOString(), version: ext.runtime.getManifest().version, motivo };
  try { trace.ping = await pingDirecto(await cfgDirect()).then(() => true).catch((e) => String((e && e.message) || e).slice(0, 80)); }
  catch (e) { trace.ping = String((e && e.message) || e).slice(0, 80); }
  const s = await ext.storage.local.get({ pending_links: {}, truncated_recent: [] });
  trace.pendientes = Object.keys(s.pending_links || {}).length;
  trace.truncados = (s.truncated_recent || []).length;
  let resueltos = 0;
  for (const [aid, p] of Object.entries(s.pending_links || {})) {
    if (Date.now() - Date.parse(p.at || 0) > 7 * 864e5) { delete s.pending_links[aid]; continue; }
    resueltos++;
  }
  trace.pendientes_vivos = resueltos;
  await ext.storage.local.set({ pending_links: s.pending_links });
  const q = await ext.storage.local.get({ cola: [] });
  trace.cola = (q.cola || []).length;
  const item = { v: 2, kind: "selftest", clicked_at: trace.at, url: "selftest:" + motivo,
    id: "self-" + Date.now().toString(36), traza: trace, text: JSON.stringify(trace).slice(0, 2000) };
  const r = await enviar(item);
  return Object.assign({ uid: item.uid, trace }, r);
}
ext.alarms.onAlarm.addListener((a) => {
  syncOn().then((on) => { if (!on) return;   // sin sync: cero tráfico de fondo
    if (a.name === "latido") enviar({ v: 2, kind: "ping", clicked_at: new Date().toISOString() });
    if (a.name === "reintento") ext.storage.local.get({ cola: [], selftest: false }).then((s) => {
      if (s.cola.length) vaciar();
      if (s.selftest) revisarComandosDirectos().catch(() => {});
    }); });
});
// Al instalar/actualizar: inyectar en pestañas de X ya abiertas (si no, no detecta nada hasta recargar).
ext.runtime.onInstalled.addListener(async (det) => {
  alarmas();
  await migrar();
  try {
    const s = await ext.storage.local.get({ selftest: false });
    if (s.selftest) await autoPrueba(det.reason || "install");
  } catch (e) {}
  if (!ext.scripting) return;
  const tabs = await ext.tabs.query({ url: ["https://x.com/*", "https://twitter.com/*", "https://mobile.x.com/*", "https://mobile.twitter.com/*"] });
  for (const t of tabs) {
    try { await ext.scripting.insertCSS({ target: { tabId: t.id }, files: ["content.css"] });
          await ext.scripting.executeScript({ target: { tabId: t.id }, files: ["content.js"] }); } catch (e) {}
  }
});
// Emparejamiento web (sin códigos): la página privada de echolike.app envía las
// credenciales tras un clic. Solo se acepta ese origen; el código se valida igual.
if (ext.runtime.onMessageExternal && ext.runtime.onMessageExternal.addListener) ext.runtime.onMessageExternal.addListener((m, remitente, responder) => {
  const ok_origen = remitente && remitente.url === "https://echolike.app/private/" || remitente && remitente.url === "https://echolike.app/es/private/";
  if (!ok_origen || !m || m.tipo !== "emparejar") { responder({ ok: false, error: t("errUnauthorizedOrigin") }); return true; }
  (async () => {
    await ext.storage.local.set({ inbox_url: String(m.inbox_url || INBOX_DEFAULT), device_token: String(m.device_token || ""), transport: "direct", sync: true });
    const r = await enviar({ v: 2, kind: "ping", prueba: true, clicked_at: new Date().toISOString() });
    return { ok: !!r.ok, version: ext.runtime.getManifest().version, error: r.error || null };
  })().then(responder, (e) => responder({ ok: false, error: String(e && e.message || e) }));
  return true;
});
if (typeof module !== "undefined") module.exports = { INBOX_DEFAULT };
