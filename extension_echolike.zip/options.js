// EchoLike single page: Likes table | Agent channel | Settings. Grouped, no advanced-fold.
const ext = typeof browser !== "undefined" ? browser : chrome;
const $ = (i) => document.getElementById(i);
const send = (m) => new Promise((ok) => ext.runtime.sendMessage(m, (r) => ok(ext.runtime.lastError ? { ok: false, error: ext.runtime.lastError.message } : r)));
const hora = (s) => { try { return s ? new Date(s).toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" }) : ""; } catch (e) { return ""; } };
const fechaHora = (s) => { try { return s ? new Date(s).toLocaleString([], { day: "2-digit", month: "2-digit", hour: "2-digit", minute: "2-digit" }) : ""; } catch (e) { return String(s || ""); } };
const esc = (s) => String(s ?? "").replace(/[&<>"]/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;" }[c]));
const texto = (el, txt, ok) => { if (!el) return; el.textContent = txt; el.className = ok ? "ok" : "err"; };
const DOMINIOS = ["x.com", "twitter.com", "mobile.x.com"];
const NOVEDADES = [
  ["2.17.0", "Bridge reaches the phone over Tailscale with device-token auth."],
  ["2.13.x", "Agent fetches pages itself in a background tab; direct command channel via the inbox."],
  ["2.12.0", "Permissions with drive mode and audit log; self-tests after every update."],
  ["2.11.x", "Full-post capture, article and thread enrichment, honesty gate on analysis."],
];
function diagResumen(it) {
  const z = it.traza || {};
  if (z.error) return "diag failed: " + String(z.error).slice(0, 60);
  const que = z.es_articulo ? ("article " + z.es_articulo) : z.es_tweet ? ("tweet " + z.es_tweet) : (it.url || "");
  return ("diag " + que).slice(0, 120);
}
document.querySelectorAll("nav.tabs button").forEach((b) => {
  b.onclick = () => {
    document.querySelectorAll("nav.tabs button").forEach((x) => x.classList.remove("on"));
    document.querySelectorAll(".tab").forEach((x) => x.classList.remove("on"));
    b.classList.add("on");
    const sec = document.getElementById("tab-" + b.getAttribute("data-tab"));
    if (sec) sec.classList.add("on");
  };
});
async function pintar() {
  $("ver").textContent = ext.runtime.getManifest().version;
  const s = await ext.storage.local.get({ sync: false, datos: [], eventos: [], inbox_url: "", device_token: "", mic: true, selftest: false, drive: false, write: {}, auditoria: [], pending_links: {}, truncated_recent: [] });
  const n = (s.datos || []).length;
  const nrec = (s.eventos || []).filter((e) => e.estado === "recibido").length;
  let head;
  if (!s.sync) head = `Local only — ${n} saved in this browser`;
  else if (!(s.inbox_url && s.device_token)) head = "No inbox connected";
  else head = `Sync on — ${n} saved, ${nrec} confirmed`;
  if ($("estado")) $("estado").textContent = head;
  // Likes table
  const evByUid = {};
  for (const e of s.eventos || []) if (e && e.uid) evByUid[e.uid] = e;
  const rows = (s.datos || []).slice(-60).reverse().map((it) => {
    const e = evByUid[it.uid];
    const estado = !e ? (s.sync ? "queued" : "saved here") : e.estado === "recibido" ? "in inbox" : e.estado;
    const cls = estado === "in inbox" ? "rec" : estado === "error" ? "err" : "ok";
    const txt = it.kind === "diagnostico" ? diagResumen(it) : it.kind === "selftest" ? "self-test report" : (it.text || it.nota || "");
    return `<tr><td class=tm title="${esc(it.clicked_at || it.saved_at || "")}">${hora(it.clicked_at || it.saved_at)}</td>` +
      `<td class=kd>${esc(it.kind)}</td><td class=hd>${it.handle ? "@" + esc(it.handle) : "—"}</td>` +
      `<td title="${esc(txt)}">${esc(txt)}</td><td class="st ${cls}">${esc(estado)}</td></tr>`;
  }).join("");
  if ($("items")) $("items").innerHTML = rows || `<tr><td><small>Nothing captured yet.</small></td></tr>`;
  // Agent tab
  if ($("drive")) $("drive").checked = !!s.drive;
  const box = $("drivebox");
  if (box) box.className = s.drive ? "okbox" : "warnbox";
  if ($("dominios")) {
    $("dominios").innerHTML = DOMINIOS.map((d) =>
      `<div class="row"><code>${esc(d)}</code><span style="flex:1"></span><label><input type="checkbox" data-dom="${esc(d)}" ${s.write && s.write[d] ? "checked" : ""} ${s.drive ? "" : "disabled"}> act here</label></div>`
    ).join("");
    $("dominios").querySelectorAll("input[data-dom]").forEach((el) => {
      el.onchange = async () => {
        const cur = await ext.storage.local.get({ write: {} });
        const w = cur.write || {};
        if (el.checked) w[el.getAttribute("data-dom")] = true; else delete w[el.getAttribute("data-dom")];
        await ext.storage.local.set({ write: w });
        await send({ tipo: "auditar", accion: "permiso", detalle: el.getAttribute("data-dom") + "=" + (el.checked ? "write" : "read") });
        pintar();
      };
    });
  }
  if ($("selftest")) $("selftest").checked = !!s.selftest;
  const rows2 = (s.auditoria || []).slice(-40).reverse().map((a) =>
    `<div title="${esc(a.at || "")}">${fechaHora(a.at)} · <b>${esc(a.accion || "")}</b> · ${esc(a.detalle || "")} · ${esc(a.origen || "")}</div>`).join("");
  if ($("auditoria")) $("auditoria").innerHTML = rows2 || "No agent actions recorded yet.";
  // Settings tab
  if ($("sync")) $("sync").checked = !!s.sync;
  if ($("mic")) $("mic").checked = s.mic !== false;
  if (!$("inbox_url").value) $("inbox_url").value = s.inbox_url || "";
  const nn = $("novedades");
  if (nn) nn.innerHTML = NOVEDADES.map(([v, d]) => `<li><b>${v}</b> — ${d}</li>`).join("");
}
function urlOk(raw) {
  try {
    const u = new URL(raw);
    if (u.port === "8904") { texto($("msgInbox"), "Wrong port: that one is a different service.", false); return null; }
    if (u.protocol === "https:" && /^(\d+\.\d+\.\d+\.\d+|localhost|\[.*\])$/.test(u.hostname)) {
      texto($("msgInbox"), "HTTPS to an IP/localhost will fail: use http:// for local addresses.", false); return null;
    }
    return u;
  } catch (e) { texto($("msgInbox"), "That address does not look like a URL.", false); return null; }
}
async function conectar() {
  const raw = $("inbox_url").value.trim().replace(/\/$/, "");
  if (!urlOk(raw)) return;
  texto($("msgInbox"), "Connecting…", true);
  let health = null;
  try {
    const r = await fetch(raw + "/api/health", { cache: "no-store" });
    health = r.ok ? await r.json() : null;
  } catch (e) { texto($("msgInbox"), "Cannot reach it. Is server.py running there?", false); return; }
  if (!health || !health.ok) { texto($("msgInbox"), "That server did not answer like an inbox.", false); return; }
  const guardado = await ext.storage.local.get({ inbox_url: "", device_token: "" });
  let token = (guardado.inbox_url === raw && guardado.device_token) ? guardado.device_token : "";
  if (!token) {
    try {
      const r = await fetch(raw + "/api/claim", { method: "POST" });
      const j = await r.json();
      if (j && j.device_token) token = j.device_token;
      else { texto($("msgInbox"), "Claim failed: " + ((j && j.error) || r.status), false); return; }
    } catch (e) { texto($("msgInbox"), "Cannot reach it. Is server.py running there?", false); return; }
  }
  const r = await send({ tipo: "directConfig", inbox_url: raw, device_token: token });
  if (!r || !r.ok) { texto($("msgInbox"), (r && r.error) || "Could not save.", false); return; }
  await ext.storage.local.set({ inbox_url: raw, device_token: token, transport: "direct", sync: true });
  const test = await send({ tipo: "prueba" });
  if (test && test.ok) { texto($("msgInbox"), "Connected to " + raw, true); await pintar(); return; }
  texto($("msgInbox"), "Saved, but the test ping failed: " + ((test && test.error) || "?"), false);
}
async function probar() {
  const url = ($("url") && $("url").value || "").trim();
  const box = $("diag");
  if (!url) { if (box) box.textContent = "Paste a URL first."; return; }
  box.textContent = "Testing…";
  const r = await send({ tipo: "diagnostico", url });
  box.textContent = r && r.ok
    ? "Saved locally, sending to inbox…\n" + JSON.stringify(r.trace, null, 1).slice(0, 1200)
    : "Test failed: " + ((r && r.error) || "no answer from background");
  pintar();
  setTimeout(async () => { await send({ tipo: "acuses" }); pintar(); }, 8000);
}
$("conectar").onclick = conectar;
$("inbox_url").addEventListener("keydown", (e) => { if (e.key === "Enter") conectar(); });
$("sync").onchange = async () => { await send({ tipo: "sync", on: $("sync").checked }); pintar(); };
if ($("mic")) $("mic").onchange = async () => { await ext.storage.local.set({ mic: $("mic").checked }); };
if ($("selftest")) $("selftest").onchange = async () => { await ext.storage.local.set({ selftest: $("selftest").checked }); };
if ($("drive")) $("drive").onchange = async () => {
  await ext.storage.local.set({ drive: $("drive").checked });
  await send({ tipo: "auditar", accion: "drive", detalle: $("drive").checked ? "on" : "off" });
  pintar();
};
if ($("probarAhora")) $("probarAhora").onclick = async () => {
  texto($("msgTest"), "Running…", true);
  const r = await send({ tipo: "selftest" });
  texto($("msgTest"), r && r.ok ? ("Done, report " + (r.uid || "") + " sent.") : ("Failed: " + ((r && r.error) || "no answer")), !!(r && r.ok));
};
if ($("probar")) $("probar").onclick = probar;
if ($("url")) $("url").addEventListener("keydown", (e) => { if (e.key === "Enter") probar(); });
$("exportar").onclick = async () => {
  const r = await send({ tipo: "exportar" });
  if (!r || !r.ok) return texto($("msg"), "Export failed.", false);
  const url = URL.createObjectURL(new Blob([JSON.stringify(r.data, null, 1)], { type: "application/json" }));
  const a = document.createElement("a");
  a.href = url; a.download = "echolike-export-" + new Date().toISOString().slice(0, 10) + ".json";
  document.body.appendChild(a); a.click(); a.remove();
  setTimeout(() => URL.revokeObjectURL(url), 5000);
  texto($("msg"), "Exported " + r.data.count + " items.", true);
};
$("importar").onchange = async (e) => {
  const f = e.target.files && e.target.files[0];
  if (!f) return;
  let obj;
  try { obj = JSON.parse(await f.text()); } catch (x) { return texto($("msg"), "That file is not valid JSON.", false); }
  const r = await send({ tipo: "importar", data: obj });
  e.target.value = "";
  if (!r || !r.ok) return texto($("msg"), "Import failed.", false);
  texto($("msg"), "Imported " + r.added + " of " + r.total + ".", true);
  pintar();
};
ext.storage.onChanged.addListener(() => pintar());
pintar();
