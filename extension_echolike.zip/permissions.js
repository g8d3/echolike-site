// Permissions page: the user sees and manages everything the agent may do.
const ext = typeof browser !== "undefined" ? browser : chrome;
const $ = (i) => document.getElementById(i);
const send = (m) => new Promise((ok) => ext.runtime.sendMessage(m, (r) => ok(ext.runtime.lastError ? { ok: false, error: ext.runtime.lastError.message } : r)));
const esc = (s) => String(s ?? "").replace(/[&<>"]/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;" }[c]));
const DOMINIOS = ["x.com", "twitter.com", "mobile.x.com"];
async function pintar() {
  const s = await ext.storage.local.get({ drive: false, write: {}, auditoria: [] });
  if ($("drive")) $("drive").checked = !!s.drive;
  const box = $("drivebox");
  if (box) { box.className = s.drive ? "okbox" : "warnbox"; }
  if ($("dominios")) {
    $("dominios").innerHTML = DOMINIOS.map((d) =>
      `<tr><td><code>${esc(d)}</code></td><td style="text-align:right"><label><input type="checkbox" data-dom="${esc(d)}" ${s.write && s.write[d] ? "checked" : ""} ${s.drive ? "" : "disabled"}> act here</label></td></tr>`
    ).join("");
    $("dominios").querySelectorAll("input[data-dom]").forEach((el) => {
      el.onchange = async () => {
        const cur = await ext.storage.local.get({ write: {} });
        const w = cur.write || {};
        if (el.checked) w[el.getAttribute("data-dom")] = true; else delete w[el.getAttribute("data-dom")];
        await ext.storage.local.set({ write: w });
        await send({ tipo: "auditar", accion: "permiso", detalle: el.getAttribute("data-dom") + "=" + (el.checked ? "write" : "read") });
        pintar();
      };
    });
  }
  if ($("auditoria")) {
    const rows = (s.auditoria || []).slice(-40).reverse();
    $("auditoria").innerHTML = rows.length ? rows.map((a) =>
      `<div>${esc(a.at || "")} · <b>${esc(a.accion || "")}</b> · ${esc(a.detalle || "")} · ${esc(a.origen || "")}</div>`
    ).join("") : "No agent actions recorded yet.";
  }
}
if ($("drive")) $("drive").onchange = async () => {
  await ext.storage.local.set({ drive: $("drive").checked });
  await send({ tipo: "auditar", accion: "drive", detalle: $("drive").checked ? "on" : "off" });
  pintar();
};
ext.storage.onChanged.addListener(() => pintar());
pintar();
if (typeof module !== "undefined") module.exports = {};
