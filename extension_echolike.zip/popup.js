// EchoLike popup (minimal): version, status, URL test box, captured-items table.
// Everything configurable lives on the settings page (options.html).
const ext = typeof browser !== "undefined" ? browser : chrome;
const $ = (i) => document.getElementById(i);
const send = (m) => new Promise((ok) => ext.runtime.sendMessage(m, (r) => ok(ext.runtime.lastError ? { ok: false, error: ext.runtime.lastError.message } : r)));
const hora = (s) => { try { return s ? new Date(s).toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" }) : ""; } catch (e) { return ""; } };
function diagResumen(it) {
  const z = it.traza || {};
  if (z.error) return "diag failed: " + String(z.error).slice(0, 60);
  const que = z.es_articulo ? ("article " + z.es_articulo) : z.es_tweet ? ("tweet " + z.es_tweet) : (it.url || "");
  const pg = z.pagina && z.pagina.article_chars ? (" · page " + z.pagina.article_chars + " chars")
    : z.pagina && z.pagina.error ? " · page: " + String(z.pagina.error).slice(0, 40) : "";
  return ("diag " + que + pg).slice(0, 120);
}
const esc = (s) => String(s ?? "").replace(/[&<>"]/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;" }[c]));
async function pintar() {
  const st = await ext.storage.local.get({ datos: [], eventos: [], sync: false, transport: "direct", inbox_url: "", device_token: "" });
  if ($("ver")) $("ver").textContent = ext.runtime.getManifest().version;
  const n = (st.datos || []).length;
  const nrec = (st.eventos || []).filter((e) => e.estado === "recibido").length;
  const ready = !!(st.inbox_url && st.device_token);
  let head;
  if (!st.sync) head = `<span class=ok>Local only — ${n} saved in this browser</span>`;
  else if (!ready && (st.transport || "direct") !== "legacy") head = `<span class=warn>No inbox configured</span>`;
  else head = `<span class=ok>Sync on — ${n} saved, ${nrec} confirmed</span>`;
  if ($("estado")) $("estado").innerHTML = head;
  const evByUid = {};
  for (const e of st.eventos || []) if (e && e.uid) evByUid[e.uid] = e;
  const rows = (st.datos || []).slice(-30).reverse().map((it) => {
    const e = evByUid[it.uid];
    const estado = !e ? (st.sync ? "queued" : "saved here") : e.estado === "recibido" ? "in inbox" : e.estado;
    const cls = estado === "in inbox" ? "rec" : estado === "error" ? "err" : "ok";
    const txt = it.kind === "diagnostico" ? diagResumen(it) : (it.text || it.nota || "");
    return `<tr><td class=tm title="${esc(it.clicked_at || it.saved_at || "")}">${hora(it.clicked_at || it.saved_at)}</td>` +
      `<td class=kd>${esc(it.kind)}</td>` +
      `<td class=hd>${it.handle ? "@" + esc(it.handle) : "—"}</td>` +
      `<td title="${esc(txt)}">${esc(txt)}</td>` +
      `<td class="st ${cls}">${esc(estado)}${e && e.error ? " · " + esc(String(e.error).slice(0, 40)) : ""}</td></tr>`;
  }).join("");
  if ($("items")) $("items").innerHTML = rows || `<tr><td><small>Nothing captured yet — like or bookmark a post on X.</small></td></tr>`;
}
async function probar() {
  const url = ($("url") && $("url").value || "").trim();
  const box = $("diag");
  if (!url) { if (box) { box.style.display = ""; box.textContent = "Paste a URL first."; } return; }
  if (box) { box.style.display = ""; box.textContent = "Testing…"; }
  const r = await send({ tipo: "diagnostico", url });
  if (box) {
    if (r && r.ok) box.textContent = "Saved locally, sending to inbox…\n" + JSON.stringify(r.trace, null, 1).slice(0, 1200);
    else box.textContent = "Test failed: " + ((r && r.error) || "no answer from background");
  }
  pintar();
  // Ask the inbox for confirmations, then repaint so the row flips to "in inbox".
  setTimeout(async () => { await send({ tipo: "acuses" }); pintar(); }, 8000);
}
if ($("settings")) $("settings").onclick = () => { try { ext.runtime.openOptionsPage(); } catch (e) {} };
if ($("probar")) $("probar").onclick = probar;
if ($("url")) $("url").addEventListener("keydown", (e) => { if (e.key === "Enter") probar(); });
try { ext.storage.onChanged.addListener(() => pintar()); } catch (e) {}
pintar();
if (typeof module !== "undefined") module.exports = { pintar, probar };
