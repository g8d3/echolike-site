const ext = typeof browser !== "undefined" ? browser : chrome;
const t = (k, s) => { try { const m = ext && ext.i18n && ext.i18n.getMessage(k, s); if (m) return m; } catch (e) {} return k; };
const $ = (i) => document.getElementById(i);
const send = (m) => new Promise((ok) => ext.runtime.sendMessage(m, (r) => ok(ext.runtime.lastError ? { ok: false, error: ext.runtime.lastError.message } : r)));
const hora = (s) => s ? new Date(s).toLocaleTimeString() : "";
function stateLabel(estado) {
  if (estado === "recibido") return t("stateReceived");
  if (estado === "enviado") return t("stateSent");
  if (estado === "en cola") return t("stateQueued");
  if (estado === "error") return t("stateError");
  if (estado === "guardado") return t("stateSavedLocal");
  return String(estado ?? "");
}
function el(tag, cls, text) {
  const n = document.createElement(tag);
  if (cls) n.className = cls;
  if (text !== undefined && text !== null) n.textContent = text;
  return n;
}
function enlace(href, text) {
  const a = document.createElement("a");
  if (href) a.href = href;
  a.target = "_blank";
  a.textContent = text;
  return a;
}
function applyI18n() {
  try {
    if (!document.querySelectorAll) return;
    const url = t("connectUrl");
    document.querySelectorAll("[data-i18n]").forEach((el) => {
      const k = el.getAttribute && el.getAttribute("data-i18n");
      if (!k || k === "footerTrouble") return;
      const m = t(k);
      if (m && m !== k) el.textContent = m;
    });
    if (document.querySelectorAll("[data-i18n-title]").forEach) {
      document.querySelectorAll("[data-i18n-title]").forEach((el) => {
        const k = el.getAttribute && el.getAttribute("data-i18n-title");
        if (!k) return;
        const m = t(k);
        if (m && m !== k) el.title = m;
      });
    }
    document.querySelectorAll("a.connectLink").forEach((a) => { if (url && url !== "connectUrl") a.href = url; });
    const foot = document.querySelector('[data-i18n="footerTrouble"]');
    if (foot) {
      const href = t("connectUrl");
      const linkText = t("privatePage");
      const tpl = t("footerTrouble", ["\u0001"]);
      if (tpl && tpl !== "footerTrouble" && tpl.includes("\u0001")) {
        const parts = tpl.split("\u0001");
        foot.textContent = "";
        const a = enlace(href && href !== "connectUrl" ? href : null, linkText);
        a.className = "connectLink";
        foot.append(parts[0], a, parts.slice(1).join("\u0001"));
      }
    }
  } catch (e) {}
}
applyI18n();
async function pintar() {
  const c = await ext.storage.local.get({ codigo: "", mic: true, eventos: [], ultimo: null, cola: [], ultimo_ack: null, hoy: null });
  $("ver").textContent = ext.runtime.getManifest().version;
  if ($("mic")) $("mic").checked = c.mic;
  const v = await send({ tipo: "validar", codigo: c.codigo });
  const evs = c.eventos || [];
  const nrec = evs.filter((e) => e.estado === "recibido").length;
  const url = t("connectUrl");
  const sync = (await ext.storage.local.get({ sync: false })).sync;
  const { datos } = await ext.storage.local.get({ datos: [] });
  if ($("sync")) $("sync").checked = sync;
  for (const id of ["probar", "conectar", "pie"]) if ($(id) && $(id).style) $(id).style.display = sync ? "" : "none";
  const pv = document.querySelector && document.querySelector('[data-i18n="privacyShort"]'); if (pv) pv.textContent = t(sync ? "privacySyncOn" : "privacyShort");
  if ($("nlocal")) $("nlocal").textContent = t("localCount", [String(datos.length)]);
  const cabeza = [];
  if (!sync) cabeza.push(el("span", "ok", t("statusLocalOnly")));
  else if (v && v.error) { cabeza.push(el("span", "warn", t("notConnected")), " ", enlace(url, t("connectOneClick"))); }
  else if (nrec > 0) cabeza.push(el("span", "ok", t("statusConnected")));
  else { cabeza.push(el("span", "warn", t("statusNoConfirm")), " ", enlace(url, t("openPrivateConnect"))); }
  const u = c.ultimo;
  const box = document.getElementById("parbox");
  if (box && box.style) box.style.display = sync && ((v && v.error) || nrec === 0) ? "" : "none";
  const cd = document.getElementById("codigo");
  if (cd) { const cc = document.getElementById("codigoCorto"); if (cc) cc.textContent = c.codigo ? c.codigo.slice(0, 8) + "…" : ""; cd.onclick = async () => { try { await navigator.clipboard.writeText(c.codigo || ""); const ok2 = document.getElementById("copiado"); if (ok2) ok2.textContent = t("copied"); } catch (e) {} }; }
  const h = c.hoy && c.hoy.d === new Date().toLocaleDateString("en-CA") ? c.hoy : { likes: 0, bookmarks: 0 };
  const est = $("estado"); est.textContent = "";
  est.append(...cabeza);
  if (u) {
    est.append(document.createElement("br"), `${t("lastLabel")} ${u.kind} ${hora(u.at)} \u2014 `);
    est.append(el("span", u.estado === "error" ? "err" : u.estado === "recibido" ? "rec" : "ok", stateLabel(u.estado)));
    if (u.error) est.append(" \u00b7 " + u.error);
  } else {
    est.append(document.createElement("br"), t("nothingSentYet"));
  }
  if (c.cola.length && sync) {
    est.append(document.createElement("br"));
    est.append(el("span", "err", t("pendingRetry", [String(c.cola.length)])));
  }
  if (sync) {
    est.append(document.createElement("br"));
    const sm = el("small"); sm.textContent = t("lastConfirm", [c.ultimo_ack && nrec > 0 ? hora(c.ultimo_ack) : t("never")]);
    est.append(sm);
  }
  $("hoy").textContent = t("todayCounter", [String(h.likes), String(h.bookmarks)]);
  const tev = $("ev"); tev.textContent = "";
  for (const e of c.eventos) {
    const tr = document.createElement("tr");
    for (const txt of [hora(e.at), e.kind, e.handle ? "@" + e.handle : ""]) {
      const td = document.createElement("td"); td.textContent = txt; tr.append(td);
    }
    const tdE = document.createElement("td");
    tdE.className = e.estado === "error" ? "err" : e.estado === "recibido" ? "rec" : "ok";
    tdE.textContent = stateLabel(e.estado);
    if (e.error) { tdE.append(document.createElement("br"), e.error); }
    tr.append(tdE);
    tev.append(tr);
  }
}
// Consentimiento de datos de Firefox (140+): se pide al activar sync, dentro del gesto del usuario.
// En Chrome o Firefox antiguo no existe esa API y el propio interruptor es el consentimiento.
async function pedirDatos() {
  try {
    const P = ext.permissions;
    if (!P || !P.request || !P.contains) return true;
    if (await P.contains({ dataCollection: ["websiteContent"] })) return true;
    return await P.request({ dataCollection: ["websiteContent"] });
  } catch (e) { return true; }
}
if ($("sync")) $("sync").onchange = async () => {
  if ($("sync").checked && !(await pedirDatos())) { $("sync").checked = false; pintar(); return; }
  await send({ tipo: "sync", on: $("sync").checked }); pintar();
};
if ($("datosLink")) $("datosLink").onclick = (e) => { e.preventDefault(); ext.runtime.openOptionsPage(); };
if ($("mic")) $("mic").onchange = async () => { await ext.storage.local.set({ mic: $("mic").checked }); };
$("probar").onclick = async () => {
  $("estado").textContent = t("sendingTest"); const r = await send({ tipo: "prueba" }); await pintar();
  if (r && r.ok) setTimeout(async () => { await send({ tipo: "acuses" }); pintar(); }, 8000);
};
ext.storage.onChanged.addListener(() => pintar());
pintar(); send({ tipo: "acuses" }).then(pintar);
