// EchoLike popup (minimal): version, status, URL test box, captured-items table.
// Everything configurable lives on the settings page (options.html).
const ext = typeof browser !== "undefined" ? browser : chrome;
const $ = (i) => document.getElementById(i);
const send = (m) => new Promise((ok) => ext.runtime.sendMessage(m, (r) => ok(ext.runtime.lastError ? { ok: false, error: ext.runtime.lastError.message } : r)));
const hora = (s) => { try { return s ? new Date(s).toLocaleTimeString() : ""; } catch (e) { return ""; } };
const esc = (s) => String(s ?? "").replace(/[&<>"]/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;" }[c]));
async function pintar() {
  const st = await ext.storage.local.get({ datos: [], eventos: [], sync: false, transport: "direct", inbox_url: "", device_token: "" });
  if ($("ver")) $("ver").textContent = ext.runtime.getManifest().version;
  const n = (st.datos || []).length;
  const nrec = (st.eventos || []).filter((e) => e.estado === "recibido").length;
  const ready = !!(st.inbox_url && st.device_token);
  let head;
  if (!st.sync) head = `<span class=ok>Local only — ${n} saved in this browser</span>`;
  else if (!ready && (st.transport || "direct") !== "legacy") head = `<span class=warn>No inbox configured</span>`;
  else head = `<span class=ok>Sync on — ${n} saved, ${nrec} confirmed</span>`;
  if ($("estado")) $("estado").innerHTML = head;
  const evByUid = {};
  for (const e of st.eventos || []) if (e && e.uid) evByUid[e.uid] = e;
  const rows = (st.datos || []).slice(-30).reverse().map((it) => {
    const e = evByUid[it.uid];
    const cls = !e ? "ok" : e.estado === "error" ? "err" : e.estado === "recibido" ? "rec" : "ok";
    return `<tr><td>${hora(it.clicked_at || it.saved_at)}</td><td>${esc(it.kind)}</td>` +
      `<td>${it.handle ? "@" + esc(it.handle) : ""}</td>` +
      `<td>${esc((it.text || it.nota || "").slice(0, 80))}</td>` +
      `<td class=${cls}>${esc(e ? e.estado : "saved")}</td></tr>`;
  }).join("");
  if ($("items")) $("items").innerHTML = rows || `<tr><td><small>Nothing captured yet — like or bookmark a post on X.</small></td></tr>`;
}
async function probar() {
  const url = ($("url") && $("url").value || "").trim();
  const box = $("diag");
  if (!url) { if (box) { box.style.display = ""; box.textContent = "Paste a URL first."; } return; }
  if (box) { box.style.display = ""; box.textContent = "Testing…"; }
  const r = await send({ tipo: "diagnostico", url });
  if (box) {
    if (r && r.ok) box.textContent = "Sent as diagnostic " + (r.uid || "") + " — trace:\n" + JSON.stringify(r.trace, null, 1).slice(0, 2000);
    else box.textContent = "Test failed: " + ((r && r.error) || "no answer from background");
  }
  pintar();
}
if ($("settings")) $("settings").onclick = () => { try { ext.runtime.openOptionsPage(); } catch (e) {} };
if ($("probar")) $("probar").onclick = probar;
if ($("url")) $("url").addEventListener("keydown", (e) => { if (e.key === "Enter") probar(); });
try { ext.storage.onChanged.addListener(() => pintar()); } catch (e) {}
pintar();
if (typeof module !== "undefined") module.exports = { pintar, probar };
